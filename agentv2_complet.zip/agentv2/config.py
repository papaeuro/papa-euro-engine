# config.py — Toutes les clés API

TELEGRAM_TOKEN   = "8719297245:AAFBbYXtgwoUG8SrG98ayTohKjdUwBTnzqQ"
TELEGRAM_CHAT_ID = "6966273085"

GROQ_API_KEY     = "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"
GEMINI_API_KEY   = "AIzaSyBYs6HoRv5W_8JXPaztniKGi7ggm8Cprss"
SERPAPI_KEY      = "5f1608033f4e145ce550288b3f9ecca558a5095f5d962268dd5b63e768c37acc"

GROQ_MODEL       = "llama3-70b-8192"
DATA_FILE        = "agent_data.json"

REPORT_HOUR      = 23
REPORT_MINUTE    = 59
